These are some Python helper scripts to help generate sample test arrays.
